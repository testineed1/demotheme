<?php 
register_post_type( 'service',
    array(
    'labels'             => array(
    'name'               => __('Service'            		),
    'singular_name'      => __('Service'                    ),
    'add_new'            => __('Add Service'                ),
    'all_items'          => __('All Service'                ),
    'add_new_item'       => __('Add New Service'            ),
    'edit_item'          => __('Edit Service'               ),
    'new_item'           => __('New Service'                ),
    'view_item'          => __('View Service'               ),
    'search_items'       => __('Search Service'             ),
    'not_found'          => __('No Service found'           ),
    'not_found_in_trash' => __('No Service found in Trash'  )
    ),
    'public'       => true,
        'publicly_queryable'  => false,
    'has_archive'  => true,
    'menu_icon'    => 'dashicons-wordpress',
    'rewrite'      => array('slug'=>'service'),
    'supports'     => array( 'title','editor','thumbnail','thumbnail','excerpt','custom-fields'),
    )
); 
?>