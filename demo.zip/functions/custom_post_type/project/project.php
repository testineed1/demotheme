<?php 
register_post_type( 'project',
    array(
    'labels'             => array(
    'name'               => __('Project'            		),
    'singular_name'      => __('Project'                    ),
    'add_new'            => __('Add Project'                ),
    'all_items'          => __('All Project'                ),
    'add_new_item'       => __('Add New Project'            ),
    'edit_item'          => __('Edit Project'               ),
    'new_item'           => __('New Project'                ),
    'view_item'          => __('View Project'               ),
    'search_items'       => __('Search Project'             ),
    'not_found'          => __('No Project found'           ),
    'not_found_in_trash' => __('No Project found in Trash'  )
    ),
    'public'       => true,
    'has_archive'  => true,
        'publicly_queryable'  => false,
    'menu_icon'    => 'dashicons-clipboard',
    'rewrite'      => array('slug'=>'project'),
    'supports'     => array( 'title','editor','thumbnail'),
    )
); 
?>