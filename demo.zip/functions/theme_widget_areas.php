<?php 
if (function_exists('register_sidebar')) {
    register_sidebar(array(
       'description'   => '',
        'class'         => '',
	'before_widget' => '<li id="%1$s" class="widget %2$s">',
	'after_widget'  => '</li>',
	'before_title'  => '<h2 class="widgettitle">',
	'after_title'   => '</h2>' ,
        'name' => 'Search',
        'id' => 'search'
    ));
    
    register_sidebar(array(
       'description'   => '',
        'class'         => '',
	'before_widget' => '<li id="%1$s" class="widget %2$s">',
	'after_widget'  => '</li>',
	'before_title'  => '<h2 class="widgettitle">',
	'after_title'   => '</h2>',
        'name' => 'Sidebar',
        'id' => 'sidebar'
    ));
    
    register_sidebar(array(
       'description'   => '',
        'class'         => '',
	'before_widget' => '<section class="widget %2$s"  id="%1$s" >',
	'after_widget'  => '</section>',
	'before_title'  => '<h4 class="widget-title">',
	'after_title'   => '</h4><hr>',
        'name' => 'Footer 1st Column',
        'id' => 'footer1'
    ));
    
    register_sidebar(array(
       'description'   => '',
        'class'         => '',
	'before_widget' => '<section class="widget %2$s"  id="%1$s" >',
	'after_widget'  => '</section>',
	'before_title'  => '<h4 class="widget-title">',
	'after_title'   => '</h4><hr>',
        'name' => 'Footer 2nd Column',
        'id' => 'footer2'
    ));
    
    register_sidebar(array(
       'description'   => '',
        'class'         => '',
	'before_widget' => '<section class="widget %2$s"  id="%1$s" >',
	'after_widget'  => '</section>',
	'before_title'  => '<h4 class="widget-title">',
	'after_title'   => '</h4><hr>',
        'name' => 'Footer 3rd Column',
        'id' => 'footer3'
    ));

    register_sidebar(array(
       'description'   => '',
        'class'         => '',
    'before_widget' => '<section class="widget %2$s"  id="%1$s" >',
    'after_widget'  => '</section>',
    'before_title'  => '<h4 class="widget-title">',
    'after_title'   => '</h4>',
        'name' => 'Footer 4th Column',
        'id' => 'footer4'
    ));
}
?>