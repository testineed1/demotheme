<?php
add_action( 'init', 'create_post_type' );

function create_post_type()
{	
//    include 'custom_post_type/slider/slider.php';   
    include 'custom_post_type/testimonial/testimonial.php';   
    include 'custom_post_type/service/service.php';   
    include 'custom_post_type/project/project.php';   
}


add_action( 'init', 'service_taxonomies', 0 );

function service_taxonomies() {
	$labels = array(
		'name'              => _x( 'Service Type', 'taxonomy general name', 'textdomain' ),
		'singular_name'     => _x( 'Service Type', 'taxonomy singular name', 'textdomain' ),
		'search_items'      => __( 'Search Service Type', 'textdomain' ),
		'all_items'         => __( 'All Service Type', 'textdomain' ),
		'parent_item'       => __( 'Parent Service Type', 'textdomain' ),
		'parent_item_colon' => __( 'Parent Service Type:', 'textdomain' ),
		'edit_item'         => __( 'Edit Service Type', 'textdomain' ),
		'update_item'       => __( 'Update Service Type', 'textdomain' ),
		'add_new_item'      => __( 'Add New Service Type', 'textdomain' ),
		'new_item_name'     => __( 'New Service Type Name', 'textdomain' ),
		'menu_name'         => __( 'Service Type', 'textdomain' ),
	);

	$args = array(
		'hierarchical'      => true,
		'labels'            => $labels,
		'show_ui'           => true,
		'show_admin_column' => true,
		'query_var'         => true,
		'rewrite'           => array( 'slug' => 'service-type' ),
	);

	register_taxonomy( 'service-type', array( 'service' ), $args );

}

add_action( 'init', 'project_taxonomies', 0 );

function project_taxonomies() {
	$labels = array(
		'name'              => _x( 'Project Type', 'taxonomy general name', 'textdomain' ),
		'singular_name'     => _x( 'Project Type', 'taxonomy singular name', 'textdomain' ),
		'search_items'      => __( 'Search Project Type', 'textdomain' ),
		'all_items'         => __( 'All Project Type', 'textdomain' ),
		'parent_item'       => __( 'Parent Project Type', 'textdomain' ),
		'parent_item_colon' => __( 'Parent Project Type:', 'textdomain' ),
		'edit_item'         => __( 'Edit Project Type', 'textdomain' ),
		'update_item'       => __( 'Update Project Type', 'textdomain' ),
		'add_new_item'      => __( 'Add New Project Type', 'textdomain' ),
		'new_item_name'     => __( 'New Project Type Name', 'textdomain' ),
		'menu_name'         => __( 'Project Type', 'textdomain' ),
	);

	$args = array(
		'hierarchical'      => true,
		'labels'            => $labels,
		'show_ui'           => true,
		'show_admin_column' => true,
		'query_var'         => true,
		'rewrite'           => array( 'slug' => 'project-type' ),
	);

	register_taxonomy( 'project-type', array( 'project' ), $args );

}

?>