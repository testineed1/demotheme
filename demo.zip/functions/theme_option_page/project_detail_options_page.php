<?php 
add_action( 'admin_init', 'register_project_detail_settings' );
function register_project_detail_settings() 
{
    register_setting( 'my-own-theme-options-for-project-detail', 'recent_project_label_val' );
    register_setting( 'my-own-theme-options-for-project-detail', 'recent_project_slider_val' );
    register_setting( 'my-own-theme-options-for-project-detail', 'recent_project_btn_val' );
}
function project_detail_options_page() {
?>

<div class="wrap">
    <h2>Project Detail Options</h2>
    <?php settings_errors(); ?> 
    <form method="post" action="options.php">
        <?php settings_fields( 'my-own-theme-options-for-project-detail' ); ?>
        <?php do_settings_sections( 'my-own-theme-options-for-project-detail' ); ?>
        <?php include('bootstrap_theme_includes.php'); ?>
        <br />
        <div class="row">
            
            <div class="col-md-8">
                <div class="panel panel-default">
                    <div class="panel-heading">
                        <h3 class="panel-title">Project Detail Options</h3>
                    </div>
                    
                    <div class="panel-body">
                        
                        <label for="recent_project_label_val">Label</label>
                        <input id="recent_project_label_val" type="text" name="recent_project_label_val" value="<?php echo get_option('recent_project_label_val'); ?>" class="form-control" />
                        
                        <br />
                        
                        <label for="recent_project_slider_val">Count</label>
                        <input id="recent_project_slider_val" type="text" name="recent_project_slider_val" value="<?php echo get_option('recent_project_slider_val'); ?>" class="form-control" />
                        
                        <br />   
                        
                        <label for="recent_project_btn_val">Button Label</label>
                        <input id="recent_project_btn_val" type="text" name="recent_project_btn_val" value="<?php echo get_option('recent_project_btn_val'); ?>" class="form-control" />
                        
                        <br />   
                    </div>
                    
                </div>
            </div>
            
            <?php include 'option_page_sidebar.php'; ?>
           
        </div>
   
        <?php submit_button(); ?>
        
    </form>
</div>
<?php } 
/*My Theme Option*/
?>
