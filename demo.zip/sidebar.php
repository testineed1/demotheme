<?php if ( is_active_sidebar( 'search' ) ) { dynamic_sidebar( 'search' ); } ?>
<?php if ( is_active_sidebar( 'sidebar' ) ) { dynamic_sidebar( 'sidebar' ); } ?>