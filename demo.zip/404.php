<?php get_header(); ?>


<div class="content">
    <section class="section_404">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="img_404">
                        <img src="<?php bloginfo('template_url'); ?>/images/404.jpg" alt="404.jpg" />
                    </div>
                </div>
            </div>
        </div>
    </section>
</div>

<?php get_footer(); ?>